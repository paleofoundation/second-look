"""Repeatable private renderer proof. Never changes renderer/manuscripts/config."""
from pathlib import Path
import argparse,copy,hashlib,html,importlib.util,json,re
from pypdf import PdfReader
from pypdf.generic import ContentStream
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('guide_render',ROOT/'src/render.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
norm=lambda s:' '.join(html.unescape(re.sub('<[^>]+>',' ',s)).split())
def corehashes():return {p.relative_to(ROOT).as_posix():h(p)for folder in ['src','config','manuscripts','fixtures','assets']for p in sorted((ROOT/folder).rglob('*'))if p.is_file()and '__pycache__'not in p.parts}
def run(out):
 before=corehashes();checks=[]
 def check(name,truth):
  checks.append({'name':name,'status':'PASS'if truth else'FAIL'});assert truth,name
 cases=[('reading','manuscripts/reading-guide.json','config/second-look.json'),('signals','fixtures/signals.json','config/signals.json'),('harbors','fixtures/harbors.json','config/harbors.json')]
 results={}
 for key,mp,cp in cases:
  data=module.load(ROOT/mp);cfg=module.load(ROOT/cp);dest=out/key
  first=module.render_all(ROOT/mp,ROOT/cp,dest);firsthash={p.name:h(p)for p in dest.glob('*')if p.is_file()}
  second=module.render_all(ROOT/mp,ROOT/cp,dest);secondhash={p.name:h(p)for p in dest.glob('*')if p.is_file()}
  check(key+' identical second generation',firsthash==secondhash)
  check(key+' variants share input and renderer',first['rendererSha256']==h(ROOT/'src/render.py')and first['manuscriptSha256']==h(ROOT/mp)and first['configSha256']==h(ROOT/cp))
  texts={}
  for variant,asset in second['assets'].items():
   reader=PdfReader(dest/asset['file']);txt='\n'.join(x.extract_text()or''for x in reader.pages);texts[variant]=norm(txt)
   check(key+' '+variant+' selectable content',all(len(p.extract_text()or'')>100 for p in reader.pages))
   check(key+' '+variant+' page number and edition',all(data['edition']['version']in p.extract_text()and str(i)in p.extract_text()for i,p in enumerate(reader.pages,1)))
   check(key+' '+variant+' valid bookmark targets',all(isinstance(reader.get_destination_page_number(x),int)and reader.get_destination_page_number(x)>=0 for x in reader.outline))
   pageids={p.indirect_reference.idnum for p in reader.pages}
   good=True
   for p in reader.pages:
    for raw in p.get('/Annots',[]):
     a=raw.get_object();destref=a.get('/Dest')
     if destref:good &= isinstance(destref,list)and hasattr(destref[0],'idnum')and destref[0].idnum in pageids
   check(key+' '+variant+' internal links remain inside variant',good)
   check(key+' '+variant+' notice retained',norm(data['notice'])in texts[variant])
   check(key+' '+variant+' private state retained','PRIVATE'in txt and data['edition']['version']in txt)
   expected=[module.orcid_identity(x['orcid']) for x in data['contributors'] if x.get('orcid')]
   credits=asset['orcidCredits']
   if expected:
    check(key+' '+variant+' single structured ORCID credit',len(credits)==len(expected) and all(txt.count(identifier)==1 for identifier,url in expected))
    check(key+' '+variant+' exact canonical ORCID link',all(sum(a['uri']==url for a in asset['linkAnnotations'])==1 for identifier,url in expected))
    check(key+' '+variant+' green logo and linked visible identifier',all(c['logoColor']=='#A6CE39' and c['logoPoints']==12 and c['linkedMarkAndIdentifier'] for c in credits))
    green=(166/255,206/255,57/255)
    check(key+' '+variant+' green present in PDF drawing stream',all(any(op==b'rg' and len(args)==3 and all(abs(float(v)-target)<.00001 for v,target in zip(args,green)) for args,op in ContentStream(reader.pages[c['page']-1].get_contents(),reader).operations) for c in credits))
   else:
    check(key+' '+variant+' no invented synthetic ORCID',not credits and 'orcid.org/' not in txt and not any('orcid.org/' in a['uri'] for a in asset['linkAnnotations']))
  check(key+' summary retains all decisive limits',all(norm(x)in texts['summary']for x in data['decisiveLimits']))
  check(key+' full retains all decisive limits',all(norm(x)in texts['full']for x in data['decisiveLimits']))
  check(key+' preview is a proper subset',second['assets']['preview']['pages']<second['assets']['full']['pages']and second['assets']['preview']['sha256']!=second['assets']['full']['sha256'])
  if key=='reading':
   check('retained eight-page guide plus three-page preview and concise one-page summary',[second['assets'][v]['pages']for v in ['full','preview','summary']]==[8,3,1])
   host='https://second-look-evidence.kmfp.chatgpt.site'
   for variant,asset in second['assets'].items():
    urls={a['uri']for a in asset['linkAnnotations']}
    check('reading '+variant+' canonical correction and policy links',host+'/corrections'in urls and host+'/disclaimer'in urls)
   check('reading full and summary link named worksheet',all(host+'/downloads/second-look-worksheet.pdf'in {a['uri']for a in second['assets'][v]['linkAnnotations']}for v in ['full','summary']))
   check('reading no policy-route placeholder',all('/guide-policy'not in t and 'host route to be accepted'not in t for t in texts.values()))
  else:check(key+' table header repeats on continuation',texts['full'].count('Repeated header: layout description')>=2)
  results[key]={'files':secondhash,'assets':second['assets']}
 data=module.load(ROOT/'fixtures/signals.json');cfg=module.load(ROOT/'config/signals.json')
 for name,mutate in [('unknown preview chapter',lambda d:d.update(previewChapterIds=['missing'])),('duplicate chapter',lambda d:d['chapters'].append(d['chapters'][0])),('unknown claim source',lambda d:d.update(claimLedger=[{'sourceIds':['missing']}])) ,('release promotion',lambda d:d['release'].update(status='released')),('missing figure alt',lambda d:d['chapters'][1]['blocks'][1].pop('alt')),('invalid ORCID',lambda d:d['contributors'][0].update(orcid='https://wrong.example/fake')),('raw ORCID block',lambda d:d['chapters'][0]['blocks'].append({'type':'source','text':'0000-0002-2348-7259'}))]:
  invalid=copy.deepcopy(data);mutate(invalid)
  try:module.validate(invalid,cfg);rejected=False
  except(AssertionError,ValueError,KeyError):rejected=True
  check('reject '+name,rejected)
 check('all imported renderer/config/content/fonts unchanged',before==corehashes())
 report={'status':'PASS','rendererVersion':module.VERSION,'sameRendererForAllTopics':True,'rendererSha256':h(ROOT/'src/render.py'),'checks':checks,'checkCount':len(checks),'results':results,'unchangedInputHashes':before,'scope':'Local generation, content, structure and deterministic repeat checks only. Visual QA, accessibility and medical/product release are separate.','timestampsIncluded':False}
 module.dump(out/'proof.json',report);print(json.dumps({'status':'PASS','checks':len(checks),'rendererSha256':report['rendererSha256'],'pageCounts':{k:{v:a['pages']for v,a in r['assets'].items()}for k,r in results.items()}}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=True);run(out)
