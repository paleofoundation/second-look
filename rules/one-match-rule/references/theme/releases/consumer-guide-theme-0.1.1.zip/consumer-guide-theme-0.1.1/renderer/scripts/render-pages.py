"""Local Poppler rendering/contact sheets; inspection remains a recorded human/agent task."""
from pathlib import Path
import argparse,hashlib,json,subprocess
from PIL import Image
p=argparse.ArgumentParser();p.add_argument('--proof',required=True);p.add_argument('--out',required=True);a=p.parse_args()
proof=Path(a.proof);out=Path(a.out);out.mkdir(parents=True,exist_ok=True);records=[]
for case in ['reading','signals','harbors']:
 files=[]
 for pdf in sorted((proof/case).glob('*.pdf')):
  subprocess.run(['pdftoppm','-scale-to','1100','-png',str(pdf),str(out/pdf.stem)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  images=sorted(out.glob(pdf.stem+'-*.png'));files+=images
  records.append({'pdf':case+'/'+pdf.name,'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'renderedPages':[{'file':im.name,'sha256':hashlib.sha256(im.read_bytes()).hexdigest()}for im in images]})
 cols=4;tw,th=340,570;rows=(len(files)+cols-1)//cols;sheet=Image.new('RGB',(cols*tw,rows*th),'#ddd')
 for i,impath in enumerate(files):
  im=Image.open(impath);im.thumbnail((tw-8,th-8));sheet.paste(im,((i%cols)*tw+4,(i//cols)*th+4))
 sheet.save(out/(case+'-contact.png'))
(out/'rendered-pages.json').write_text(json.dumps({'totalPages':sum(len(x['renderedPages'])for x in records),'records':records},indent=2)+'\n')
print('Rendered',sum(len(x['renderedPages'])for x in records),'pages')
