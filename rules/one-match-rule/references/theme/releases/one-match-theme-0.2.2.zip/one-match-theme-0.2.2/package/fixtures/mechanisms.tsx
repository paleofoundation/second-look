import React from 'react';
import type {MechanismContext, MechanismPresentation} from '../src/mechanisms';
/** Synthetic presentation inputs only. No drug, experiment or clinical claim. */
export function syntheticMechanisms(topic: 'signals' | 'locations') {
  const signals=topic==='signals';
  const content: MechanismPresentation = {
    heading: signals?'How the signal works':'How the harbor works',
    introduction: signals?'This fictional signal process demonstrates the configured explanation.':'This fictional harbor process demonstrates the configured explanation.',
    originalHeading: signals?'Original signal route':'Original arrival route',
    originalUnavailable:'The original process has no verified description in this fictional record.',
    proposedHeading: signals?'Another signal context':'Another arrival context',
    proposedUnavailable:'No additional verified process is recorded for this fictional context.',
    evidenceBoundary:'This is a synthetic layout fixture. It supplies no real-world mechanism or evidence of benefit.',
    detailLabels:{target:signals?'Receiver':'Destination',action:signals?'Signal step':'Arrival step',model:'Fixture model'},
  };
  return {
    content,
    originalAction: <p>{signals?'The fictional Signal Alpha system routes input to a synthetic receiver.':'The fictional Harbor One system assigns arrivals to a synthetic bay.'} This is a layout fixture, not a biological mechanism.</p>,
    contexts: [{id:`synthetic-${topic}-mechanism`, title:signals?'A second signal context':'A second harbor context', explanation:<p>A fictional process description supplied through configuration.</p>, evidence:{basis:'not_assessed',label:'Synthetic example; no biological model or study',source:<p><a href="#fixture-source">Synthetic source [S]</a></p>,target:signals?'Invented receiver':'Invented bay',action:'Fictional routing step',model:'Imaginary objects; no experiment'}, clinicalMeaning:'This fixture has no clinical meaning and supplies no evidence of benefit.'}] satisfies MechanismContext[],
  };
}
