import React from 'react';
import {createRoot} from 'react-dom/client';
import {ThemeShell,ThemeHome,ArticleLayout,ThemeSectionNav} from '../package/src/theme';
import {MechanismSection} from '../package/src/mechanisms';
import {syntheticMechanisms} from '../package/fixtures/mechanisms';
import {InlineFaqs} from '../package/src/faqs';
import {EvidenceTable,type EvidenceSource,type EvidenceFinding} from '../package/src/evidence-table';
import {syntheticConfigA,syntheticConfigB,syntheticHome,syntheticAuthor} from '../package/fixtures/configs';
import {GuideCatalogue,GuideProductDetail,GuideMembership} from '../package/src/guide-catalogue';
import {describeEvidenceConfidence} from '../package/src/evidence-confidence';
import {syntheticGuides,syntheticConfidence} from '../package/fixtures/products';
import type {ThemeConfig} from '../package/src/types';
import '../package/src/theme.css';
import '../package/src/reading-modules.css';
import '../package/src/guide-library.css';
import './proof.css';

const params=new URLSearchParams(location.search);
const topic=params.get('topic')==='locations'?'locations':'signals';
const view=['article','catalogue','product','membership','adapter'].includes(params.get('view')||'')?params.get('view')!:'home';
const guides=syntheticGuides(topic);
const cf=syntheticConfidence(topic),confidence=describeEvidenceConfidence(cf.row,cf.sources);
const articleHref=`/?topic=${topic}&view=article`;
const href=(nextTopic:string,nextView:string)=>`/?topic=${nextTopic}&view=${nextView}`;
function FixtureLink({href:target,...props}:React.AnchorHTMLAttributes<HTMLAnchorElement>&{href:string}){
  const mapped=target.startsWith('#')||target.startsWith('/?')||target.startsWith('https:')?target:target==='/'?href(topic,'home'):target.startsWith('/account')?href(topic,'adapter'):articleHref;
  return <a {...props} href={mapped}/>;
}
const config:ThemeConfig={...(topic==='signals'?syntheticConfigA:syntheticConfigB),adapters:{Link:FixtureLink},footer:{...(topic==='signals'?syntheticConfigA:syntheticConfigB).footer,note:'Private local fixture. All people, topics, sources and numbers here are synthetic.'}};
const label=topic==='signals'?'Signal separation':'Harbor arrival spread';
const sourceId=`SYNTHETIC-${topic}-source`;
const sources:EvidenceSource[]=[{id:sourceId,title:`Synthetic ${topic} source. No real paper`,url:articleHref+'#fixture-source',year:'Synthetic date',kind:'Private fixture',primary:true,preview:'All values in this record were invented solely to exercise a reusable table and research panel. This is not research.',decisiveLimit:'There are no participants, no actual experiment and no scientific conclusion.',access:'Fixture source text is below',status:'Synthetic only',population:'Fictional test objects',design:'Layout test, not a study',reviewUrl:articleHref+'#fixture-source',reviewLabel:'Read synthetic source note',locators:['Synthetic fixture record, main.tsx; no paper locator']}];
const rows:EvidenceFinding[]=[{id:'synthetic-finding',title:label,peer:{title:`Fictional ${topic} record`,href:articleHref+'#overview'},use:'Synthetic layout demonstration',population:'24 fictional objects, not participants',comparison:'Invented group A versus invented group B',endpoint:'Synthetic units',timepoint:'Test checkpoint 1',status:'SYNTHETIC · NOT EVIDENCE',finding:'The invented fixture values are 12 versus 9 synthetic units.',magnitude:'An invented difference of 3 units. These numbers have no real-world meaning.',certainty:{label:'Not applicable: synthetic',rationale:'A layout fixture has no scientific evidence certainty.'},evidenceBase:'One synthetic source ID and one fictional family ID exercise the counts. Neither refers to a real study.',limits:[{text:'No actual research, participants or biological model exists.',sourceIds:[sourceId]}],sourceIds:[sourceId],familyIds:[`SYNTHETIC-${topic}-family`],background:false,pending:['This fixture is never eligible for scientific publication.'],details:[{label:'Fixture sample',value:'24 fictional objects, invented for layout testing'}]}];
const cite=(ids:string[])=>ids.length?<a className="proof-citation" href={articleHref+'#fixture-source'} aria-label="Read synthetic citation"> [S]</a>:null;
const groups=[{id:'overview',label:'Overview'},{id:'mechanisms',label:syntheticMechanisms(topic).content.heading},{id:'findings',label:'Findings'},{id:'faqs',label:'FAQs'},{id:'fixture-source',label:'Synthetic source'}];
function Article(){return <ArticleLayout hero={{title:`A closer look at ${topic}.`,description:<p>This is a private synthetic theme fixture. It contains no scientific claim, real drug, disease, person or study.</p>,breadcrumbs:[{label:'Fixture home',href:href(topic,'home')}],kindLabel:'SYNTHETIC FIXTURE',author:syntheticAuthor(topic),art:syntheticHome(topic).hero.image,snapshot:<div className="snapshot"><h2>Fixture snapshot</h2><p>1 synthetic source<br/>24 fictional objects<br/>0 real studies</p></div>,actions:<><a className="research-hero__center-tag" href="#findings">Inspect synthetic finding</a><a className="research-hero__center-tag" href="#faqs">Read fixture FAQs</a></>}} leftRail={<ThemeSectionNav groups={groups}/>} rightRail={<div><h2>Connected fixture</h2><p><a href={href(topic==='signals'?'locations':'signals','article')}>Open the second topic with the same template</a></p></div>}>
  <section id="overview"><h2>Overview</h2><p>The shared article layout, section navigation, evidence table, research panel and FAQs are imported from the reusable package. Topic labels and fixture data change through URL configuration.</p><p>The fictional groups below let reviewers check text density, numbers, citations and interactive behavior. They have no medical interpretation.</p></section>
  <MechanismSection {...syntheticMechanisms(topic)} />
  <section id="findings"><h2>Synthetic findings</h2><aside className="proof-confidence"><h3>{confidence.label}</h3><p>{confidence.basis}</p><p>{confidence.limitation.text}</p><p>{confidence.nextAction?.text}</p><small>Verbatim synthetic row inputs. This component has not rated evidence.</small></aside><p>Every number below is invented for this local layout test. Open either the outcome or source count to inspect the same research panel.</p><EvidenceTable rows={rows} sources={sources} cite={cite}/></section>
  <InlineFaqs items={[{id:'faq-synthetic',question:'Are these numbers real research?',answer:<p>No. The 12, 9 and 24 values are fictional test inputs used only in this private fixture.{cite([sourceId])}</p>,status:'Synthetic fixture only'},{id:'faq-shared',question:'Does switching topic edit the shared theme?',answer:<p>No. The topic query selects an existing configuration and fixture dataset. The same imported package components and styles render both topics.{cite([sourceId])}</p>}]} />
  <section id="fixture-source"><h2>Synthetic source note</h2><p id="synthetic-source-record">[S] Private fixture in main.tsx. No DOI, clinical result, participant or paper exists. The record must remain outside production data and indexes.</p></section>
</ArticleLayout>}
function GuideView(){const guide=guides.products.find(p=>p.slug===params.get('slug'))||guides.products[0];return <main id="main-content" className="proof-guide-main">{view==='catalogue'?<GuideCatalogue {...guides} notice={<p className="proof-fixture-notice">Nonmedical synthetic fixture. The medical notice is a separately configurable host component.</p>}/>:view==='product'?<GuideProductDetail guide={guide} config={guides.config}/>:view==='membership'?<GuideMembership offer={guides.offer} config={guides.config}/>:<section><h1>Host services are not connected</h1><p>This local proof has no login, saved library, purchased guide files, entitlement ledger, checkout or data collection.</p><p>A host must supply and test these real server services. A route label or disabled button does not grant access.</p><h2 id="medical">Notice and scope adapter</h2><p>The guides in this fixture are fictional and nonmedical. The shared medical notice is demonstrated on the membership page solely as UI copy, not personal advice or legal approval.</p><a href={guides.config.routes.catalogue}>Return to the synthetic guide catalogue</a></section>}</main>}
function App(){return <><div className="proof-controls" aria-label="Private fixture controls"><strong>PRIVATE LOCAL FIXTURE · ALL NUMBERS SYNTHETIC</strong><nav aria-label="Fixture topic and page">{(['signals','locations'] as const).map(t=><React.Fragment key={t}>{['home','article','catalogue','product','membership'].map(v=><a key={v} href={href(t,v)} aria-current={topic===t&&view===v?'page':undefined}>{t}: {v}</a>)}</React.Fragment>)}</nav><span>Query-selected topic: {topic} · Shared view: {view}</span></div><ThemeShell config={config}>{view==='home'?<ThemeHome content={syntheticHome(topic)}/>:view==='article'?<Article/>:<GuideView/>}</ThemeShell></>}
// Fixture host route adapter preserves query-selected identity when a shared GET form submits.
// It touches no shared source file and makes no network request.
document.addEventListener('submit',event=>{const form=event.target;if(!(form instanceof HTMLFormElement)||form.getAttribute('role')!=='search')return;event.preventDefault();const next=new URLSearchParams(location.search);next.set('view','article');next.set('q',String(new FormData(form).get(config.search.param)||''));location.assign('/?'+next.toString()+'#overview')});
createRoot(document.getElementById('root')!).render(<App/>);
