# Local two-topic theme proof — 0.2.0

Run `npm install --ignore-scripts`, `npm run check`, `npm run build` and `npm run dev` from the workspace root. Open `http://127.0.0.1:5188/?topic=signals&view=home` or `http://127.0.0.1:5188/?topic=locations&view=home`.

The fixture bar switches two synthetic configurations through the unchanged shared package. Available views are `home`, `article`, `catalogue`, `product`, `membership` and `adapter`. Twelve topic/view combinations are declared in `generated.json`. Product routes optionally add `&slug=fixture-1`, `fixture-2` or `fixture-3`.

The same menu, article, author, table, research panel, FAQ, confidence adapter and product components render both topics. All numerical values, names, product/edition identifiers, asset hashes and prices are fictional. No actual source, author, customer, entitlement or financial transaction exists. Account/library routes show the missing host-service boundary instead of pretending to sign in or purchase. General example content links resolve to the synthetic article, not a research index.

`scripts/repeat-proof.py` regenerates the fixture manifest twice and verifies byte identity and unchanged shared source. This local proof never mutates package source or real site data. Current technical, browser and service acceptance scopes are kept separately in `../package/theme-acceptance.json`. An arbitrary fixture topic order is not measured interest. A displayed medical notice is not medical/legal review. A synthetic assessed-confidence input tests a display gate, not real scientific appraisal.
