# One Match theme 0.2.6 — Evidence table correction

This is a bounded delta for the existing Second Look shared theme and host
adapters, including the 0.2.5 single-Evidence composition. It is not a standalone
application or a complete theme acceptance. Historical releases and frozen
reference snapshots remain unchanged.

## Required result

Evidence starts with visible explanatory prose. Any scoped evidence explanations
come before the final table, whose semantic columns are **Outcome and study
design / Grade / Evidence**. The outcome cell is compact, with subordinate study
design. Existing authored Benefits, Results and Evidence prose remains intact,
and full row findings, magnitude and limits remain in the matching research
panel. Grade represents evidence certainty with its actual appraisal state;
detailed explanations remain available in that panel. Evidence displays the document-icon
control and accurately labeled source counts. Both outcome and count controls
open the same row's research details in the right overlay.

The shared article plan enforces that composition for adopted Drug, Condition,
scoped-answer and comparison routes. One canonical Evidence table remains; old
findings fragments remain compatibility aliases where already adopted. A page
without synthesis rows keeps table headers and a truthful empty-state row, with
no invented grade or source count. Citation planning
follows the visible prose and table-cell order, retaining canonical identities.

## Installation into an existing compatible checkout

1. Verify `SHA256SUMS`, the archive receipt and `manifest.json`. Review its source
   version and `testedImplementationHashes`. Preserve current work; compare and
   merge mapped files when your checkout differs.
2. Merge `shared/` into `components/shared-theme/` according to `installMapping`.
   The shared EvidenceTable includes its right research panel in the same file.
3. For Second Look, merge the `host/` files at their mapped paths. In another
   application, port the same composition and citation traversal through its own
   content adapters. The host files depend on Second Look's existing canonical
   evidence, wiki, article, source and review interfaces; copying them is not a
   general-purpose scientific-content generator.
4. Retain base dependencies and the established stylesheet cascade, with
   `reading-modules.css` preceding `article-reading.css`. Existing React,
   TypeScript, radix-ui Dialog, lucide-react, confidence/prose/types components,
   theme tokens and host services remain prerequisites. This delta installs no
   dependencies or database migration and changes no evidence records.
5. Run the destination's TypeScript check, production build and applicable
   reader/access guards. Run included scoped regression scripts only with their
   existing host prerequisites. They supplement rendered checks, not replace
   them.
6. Inspect representative Drug, Condition, answer and comparison routes, a
   missing-synthesis page and regenerated content. Verify prose first/table last,
   exactly three headers, retained narrative and row findings/magnitude/limits, citation order,
   both panel openers and matching records. Check X/Escape/backdrop close,
   actual-opener focus return, background scroll restoration, source/review
   links, mobile scrolling and existing fragment aliases.

Keep the site's own identity, author assignment, brand, evidence, review-access
policy, hosting audience and scientific states. Do not copy reference medical
claims, counts or grades. Unknown or unfinished certainty never becomes Low.

## Evidence and boundaries

`validation/verification-summary.json` records only the checks actually supplied
by the integrating task, with technical report hashes/locations where provided.
`validation/status.json` separates the request, captured implementation, bounded
verification and release. The manifest records the exact packaged source hashes.
Read these statuses before claiming the implementation was deployed or tested at
a particular width. Unexecuted checks remain unverified.

No source papers, scientific data, accounts, credentials or private full reviews
are included. This delta does not establish whole-rule PASS, complete-theme G4T
acceptance, scientific appraisal, human approval, corpus completion or commerce
readiness. Packaging itself neither publishes the site nor synchronizes an
installed skill or an uploaded ChatGPT project copy.
