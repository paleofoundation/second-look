# Owner requirement and scoped rule reconciliation

The owner's 11 October 2026 request in the Drug Repurposing chat explicitly asks
that Second Look follow PepsAnon's Evidence section, its **Outcome and study
design / Grade / Evidence** table and the function opening the right sidebar for
additional study details. The owner also requires the generator to inherit it,
and that Evidence begin with prose and end in a table.

This request strengthens the existing table/panel contract and makes the Second
Look composition explicit. Principal conclusions, magnitude, uncertainty,
source identity and review-access boundaries remain mandatory. The correction
changes presentation and shared generation behavior; it does not authorize
fabricating scientific fields or treating unknown confidence as Low.

The historical 0.2.5 addendum records an earlier owner correction removing the
separate early findings view. Preserve that single-Evidence choice and its old
fragment alias. The older universal early-summary wording does not override
Second Look's current explicit direction; other sites retain their adopted
scope until changed. No historical release or frozen baseline is rewritten.

Canonical reading-ui and theme documentation record the requested behavior.
The package manifest records the master version/hash actually present at export;
it does not imply installed-skill or uploaded-project synchronization. Read the
separate status record for implemented, verified and released evidence, and keep
those states separate from adoption of the requirement.
