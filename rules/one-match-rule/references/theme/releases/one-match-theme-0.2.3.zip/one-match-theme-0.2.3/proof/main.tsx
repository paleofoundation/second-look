import React from 'react';
import {createRoot} from 'react-dom/client';
import {ThemeShell,ThemeHome,ArticleLayout,ThemeSectionNav,DirectoryPage} from '../package/src/theme';
import {SyntheticReadingArticle} from '../package/fixtures/reading';
import {syntheticMechanisms} from '../package/fixtures/mechanisms';
import {InlineFaqs} from '../package/src/faqs';
import {EvidenceTable,type EvidenceSource,type EvidenceFinding} from '../package/src/evidence-table';
import {syntheticConfigA,syntheticConfigB,syntheticHome,syntheticAuthor} from '../package/fixtures/configs';
import {GuideCatalogue,GuideProductDetail,GuideMembership} from '../package/src/guide-catalogue';
import {describeEvidenceConfidence} from '../package/src/evidence-confidence';
import {syntheticGuides,syntheticConfidence} from '../package/fixtures/products';
import type {ThemeConfig} from '../package/src/types';
import '../package/src/theme.css';
import '../package/src/reading-modules.css';
import '../package/src/guide-library.css';
import './proof.css';
import '../package/src/article-reading.css';

const params=new URLSearchParams(location.search);
const topic=params.get('topic')==='locations'?'locations':'signals';
const view=['article','catalogue','product','membership','adapter','directory'].includes(params.get('view')||'')?params.get('view')!:'home';
const guides=syntheticGuides(topic);
const cf=syntheticConfidence(topic),confidence=describeEvidenceConfidence(cf.row,cf.sources);
const articleHref=`/?topic=${topic}&view=article`;
const href=(nextTopic:string,nextView:string)=>`/?topic=${nextTopic}&view=${nextView}`;
function FixtureLink({href:target,...props}:React.AnchorHTMLAttributes<HTMLAnchorElement>&{href:string}){
  const mapped=target.startsWith('#')||target.startsWith('/?')||target.startsWith('https:')?target:target==='/'?href(topic,'home'):['/signals','/questions','/locations','/routes'].includes(target)?`/?topic=${topic}&view=directory&family=${target.slice(1)}`:target.startsWith('/account')?href(topic,'adapter'):articleHref;
  return <a {...props} href={mapped}/>;
}
const config:ThemeConfig={...(topic==='signals'?syntheticConfigA:syntheticConfigB),adapters:{Link:FixtureLink},footer:{...(topic==='signals'?syntheticConfigA:syntheticConfigB).footer,note:'Private local fixture. All people, topics, sources and numbers here are synthetic.'}};
function Article(){return <SyntheticReadingArticle topic={topic}/>;}
function Directory(){const family=params.get('family')||(topic==='signals'?'signals':'locations');const title=family.charAt(0).toUpperCase()+family.slice(1);return <DirectoryPage title={title} description="Two explicitly synthetic records demonstrate a complete fixture directory. Neither is a finished research guide." items={[1,2].map(n=>({id:family+'-'+n,title:`${title} example ${n}`,href:articleHref,description:'Synthetic layout record'}))}/>;}
function GuideView(){const guide=guides.products.find(p=>p.slug===params.get('slug'))||guides.products[0];return <main id="main-content" className="proof-guide-main">{view==='catalogue'?<GuideCatalogue {...guides} notice={<p className="proof-fixture-notice">Nonmedical synthetic fixture. The medical notice is a separately configurable host component.</p>}/>:view==='product'?<GuideProductDetail guide={guide} config={guides.config}/>:view==='membership'?<GuideMembership offer={guides.offer} config={guides.config}/>:<section><h1>Host services are not connected</h1><p>This local proof has no login, saved library, purchased guide files, entitlement ledger, checkout or data collection.</p><p>A host must supply and test these real server services. A route label or disabled button does not grant access.</p><h2 id="medical">Notice and scope adapter</h2><p>The guides in this fixture are fictional and nonmedical. The shared medical notice is demonstrated on the membership page solely as UI copy, not personal advice or legal approval.</p><a href={guides.config.routes.catalogue}>Return to the synthetic guide catalogue</a></section>}</main>}
function App(){return <><div className="proof-controls" aria-label="Private fixture controls"><strong>PRIVATE LOCAL FIXTURE · ALL NUMBERS SYNTHETIC</strong><nav aria-label="Fixture topic and page">{(['signals','locations'] as const).map(t=><React.Fragment key={t}>{['home','article','catalogue','product','membership'].map(v=><a key={v} href={href(t,v)} aria-current={topic===t&&view===v?'page':undefined}>{t}: {v}</a>)}</React.Fragment>)}</nav><span>Query-selected topic: {topic} · Shared view: {view}</span></div><ThemeShell config={config}>{view==='home'?<ThemeHome content={syntheticHome(topic)}/>:view==='article'?<Article/>:view==='directory'?<Directory/>:<GuideView/>}</ThemeShell></>}
// Fixture host route adapter preserves query-selected identity when a shared GET form submits.
// It touches no shared source file and makes no network request.
document.addEventListener('submit',event=>{const form=event.target;if(!(form instanceof HTMLFormElement)||form.getAttribute('role')!=='search')return;event.preventDefault();const next=new URLSearchParams(location.search);next.set('view','article');next.set('q',String(new FormData(form).get(config.search.param)||''));location.assign('/?'+next.toString()+'#overview')});
createRoot(document.getElementById('root')!).render(<App/>);
