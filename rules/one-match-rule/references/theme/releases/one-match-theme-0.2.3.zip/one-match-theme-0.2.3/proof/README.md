# Local two-topic theme proof — 0.2.3

Run `npm install --ignore-scripts`, `npm run check`, `npm run build` and `npm run dev` from the workspace root. Open `http://127.0.0.1:5188/?topic=signals&view=home` or `http://127.0.0.1:5188/?topic=locations&view=home`.

The fixture bar switches two synthetic configurations through the unchanged shared package. Available views are `home`, `article`, `catalogue`, `product`, `membership`, `adapter` and `directory`. Fourteen base topic/view combinations are declared in `generated.json`. Product routes optionally add `&slug=fixture-1`, `fixture-2` or `fixture-3`.

The same menu, article, author, table, research panel, FAQ, confidence adapter and product components render both topics. All numerical values, names, product/edition identifiers, asset hashes and prices are fictional. No actual source, author, customer, entitlement or financial transaction exists. Account/library routes show the missing host-service boundary instead of pretending to sign in or purchase. General example content links resolve to the synthetic article, not a research index.

`scripts/repeat-proof.py` regenerates the fixture manifest twice and verifies byte identity and unchanged shared source. This local proof never mutates package source or real site data. Current technical, browser and service acceptance scopes are kept separately in `../package/theme-acceptance.json`. An arbitrary fixture topic order is not measured interest. A displayed medical notice is not medical/legal review. A synthetic assessed-confidence input tests a display gate, not real scientific appraisal.

Version 0.2.3 imports the single structured `fixtures/reading.tsx` article for both topics. Its hero uses the exported HeroActions, with Save signal/location, Safety, FAQs, Evidence and References. Save is a local fixture toggle that explicitly warns it is not saved to an account. Prose remains visible; native FAQs and references are collapsible. Superscript references use one first-appearance registry and stable source-identity fragments with numeric aliases. Initial and repeated reference clicks use a local reveal adapter. Synthetic directories are available through the two plain first-level family links in each config. No real research or authenticated persistence is implied.

Manual browser checks are separate from SSR. Use 320/390/768/1280px, both topics, keyboard action navigation, native FAQ opening, initial/repeated References, the research panel and author placement. Do not treat earlier version browser reports as a rerun.
