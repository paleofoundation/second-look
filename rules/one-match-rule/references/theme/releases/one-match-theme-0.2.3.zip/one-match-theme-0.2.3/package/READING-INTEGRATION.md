# Article reading integration — 0.2.3

This version adds `HeroActions`, `article-reading.css` and pure citation helpers. The package supplies presentation; the host owns the full reading model, scientific source mapping, account services, canonical routes and approval states. Do not copy real evidence or account adapters into a public theme bundle.

## Import and wire the shared code

```tsx
import {ArticleLayout, HeroActions} from '@one-match/source-theme';
import {
  createCitationOrder, unknownCitationIds, orderCitationGroup,
  citationNumber, sourceReferenceId, normalizeCitationSentence,
} from '@one-match/source-theme/citations';
import '@one-match/source-theme/theme.css';
import '@one-match/source-theme/reading-modules.css';
import '@one-match/source-theme/guide-library.css';
// Import destination article styles here, then the reading layer last.
import '@one-match/source-theme/article-reading.css';

<ArticleLayout hero={{
  ...hero,
  actions: <HeroActions
    ariaLabel="Article actions"
    saveSlot={hostLibraryControl}
    links={applicableActionLinks}
  />
}}>{articleSections}</ArticleLayout>
```

`HeroActionLink` is `{label, href, icon?: ReactNode}`. The wrapper marks link icons decorative. Supply bookmark, shield, discussion, chart and book icons where applicable. Supply `Save [entity]`, Safety, FAQs, Evidence and References for the applicable entity-guide contract. The host configures terminology and actual target fragments; no control is inserted automatically merely because a prop exists. Other post types have explicit applicable action sets. Missing required content remains an unfinished-guide issue, not a reason to silently remove all actions. An empty action set renders no navigation.

Pass the service control itself in `saveSlot`, preferably using `research-hero__center-tag` on its real button/link. The slot can include a status region. The outer hero already supplies action-row spacing. Preserve the right author/snapshot region, verified identity, green ORCID link and biography interaction. Do not duplicate the author in a sidebar.

## Host library control

The reference host connects `components/library-controls.tsx` to `GET /api/library` and authenticated POST/DELETE operations with `{itemId}`. These are a reference route pattern, not bundled endpoints. Bind account ownership from the server session; accept only canonical, authorized item IDs. Get the real saved state before presenting it, reflect saving/removing/error states, use an accessible status region, and synchronize duplicate controls. An anonymous reader's action leads through supported sign-in and persisted intake to a validated same-site return path for this item. Do not infer success from clicking a decorative button.

Verify initial state, save, reload persistence, remove, unauthorized/expired sessions, network/database failures, retry, second-account isolation and duplicate-control updates against the actual host. The synthetic `FixtureSave` in `fixtures/reading.tsx` only toggles local React state and explicitly says it was not saved to an account; it is never an implementation of this contract. No server, account identifier, session token, library record or migration is exported.

## One citation plan per page

The reference host's `lib/citation-plan.ts` is a destination adapter and is intentionally not copied. It integrates source identities, outcome sentence maps, mechanisms, ordinary sections, FAQs, later source-bearing sections and protected/public route boundaries. A host must reconcile its traversal to the exact rendered sequence of each route type. Use one structured content model for rendering and traversal; adding a rendering branch must also add its source groups. Verify actual rendered first appearances to catch omissions. Do not seed numbering from bibliography order or alphabetical source IDs.

Call `unknownCitationIds(groups, availableIds)` and fail validation on unresolved identities. `createCitationOrder` itself omits unknown sources; treating this as success would silently lose citations. Canonical identity, not a URL or displayed number, is the source key. The first source encountered receives 1; repeats retain that number. `orderCitationGroup` removes duplicate requests and sorts a group by the one registry. `citationNumber` returns null for absent IDs, never citation zero. Append uncited bibliography-only records after the cited order if the host shows them.

Render a semantic linked `<sup className="citation-sup">` after the supported sentence's authored punctuation. `normalizeCitationSentence` trims trailing whitespace only. It does not add a period, alter decimals, combine source support or fix scientific prose. A table phrase may end with a superscript without invented punctuation. Preserve sentence-level sources; never imply that a row-wide union supports every sentence. Use the same registry in prose, FAQs, tables, research panels and bibliography. Build it before filters or disclosure state change; interaction must not renumber it.

Use `sourceReferenceId(sourceId)` as the stable bibliography target and preserve numeric `ref-N` compatibility aliases. This helper percent-encodes source identities. A host hash resolver should try the raw fragment and its safely decoded form without throwing; `getElementById` avoids unsafe selector interpolation. Retain canonical review destinations and useful old identity aliases after edits. A separately navigated review has its own page-local registry.

References must open the existing bibliography, including initial deep links, repeated same-hash clicks and browser back/forward. The fixture implements a small local reveal adapter as an example; hosts must test their router, sticky-header offset, focus behavior and disclosure ownership. An open research panel must use the same renderer and return focus to its trigger. Never render protected review prose merely to satisfy a citation target.

## Prose, disclosures and topic configuration

Use `.article-section` for normal direct-child narrative sections under `ArticleLayout`. The last-loaded reading layer removes repeated card backgrounds and supplies readable paragraph rhythm. Keep consequential explanations and safety limits visible. `InlineFaqs` supplies actual native details/summary disclosure and fragment reveal; optional deeper detail may use the same native structure. Keep semantic tables, source catalogues and required checklists. Do not replace tables with prose or fill sections with invented facts.

Every main family needs a clear first-level link in both desktop and mobile navigation. The synthetic configs use Signals/Questions and Locations/Routes, each with direct directory links; grouped featured menus are additional discovery. A real drug site configures its own Drugs/Conditions names and routes. Parent and scoped-question ownership, reciprocal links, breadth and unfinished status are host content contracts. This presentation export cannot convert a narrow pilot corpus into a complete parent guide.

## Current verification boundary

`fixtures/reading.tsx` is the single structured synthetic article used by the proof and SSR checks for both topics. It exercises prose, mechanisms before a later source, decimal table values, reversed/duplicate/repeated citations, initially closed FAQs, stable bibliography identity and inserted prose branches. Offline HTML parsing checks the rendered sequence and targets. Pure helper failures reject unknown identities. Neither SSR nor source inspection establishes browser interaction or host scientific completeness.

The local proof is for manual browser testing at approximately 320/390/768/1280px. Test action wrapping, right author placement, focus and keyboard operation, FAQs, initial/repeated References, research panel numbering and its return focus. Root may supply a separately scoped browser report; it does not make fixture Save an authenticated service. Scientific, editorial, clinical, legal, full-review access and paid-guide release remain independent host gates.
