import {useEffect,useRef,useState,type ReactNode} from 'react';
import {Bookmark,Check,Shield,MessagesSquare,ChartNoAxesCombined,BookOpen} from 'lucide-react';
import {ArticleLayout,ThemeSectionNav} from '../src/theme';
import {HeroActions} from '../src/article-actions';
import {MechanismSection} from '../src/mechanisms';
import {EvidenceTable,type EvidenceFinding,type EvidenceSource} from '../src/evidence-table';
import {InlineFaqs} from '../src/faqs';
import {createCitationOrder,unknownCitationIds,orderCitationGroup,citationNumber,normalizeCitationSentence,sourceReferenceId} from '../src/citations';
import {syntheticHome,syntheticAuthor} from './configs';
import {syntheticMechanisms} from './mechanisms';
export type SyntheticTopic='signals'|'locations';
type Sentence={text:string;sources:string[]};
type Prose={kind:'prose';id:string;title:string;paragraphs:Sentence[][]};
type Mechanisms={kind:'mechanisms';id:'mechanisms';title:string;original:Sentence;explanation:Sentence;source:Sentence;meaning:Sentence};
type Findings={kind:'findings';id:'findings';title:string;intro:Sentence;row:EvidenceFinding};
type Faqs={kind:'faqs';id:'faqs';title:string;items:{id:string;question:string;sentences:Sentence[]}[]};
export type ReadingBlock=Prose|Mechanisms|Findings|Faqs;
/** A single structured sequence owns both render order and citation traversal. No real sources. */
export function syntheticReadingModel(topic:SyntheticTopic){
 const ids={overview:`fixture-${topic}-z`,mechanism:`fixture-${topic}-m`,finding:`fixture-${topic}-a`,faq:`fixture-${topic}-c`,uncited:`fixture-${topic}-unused`};
 const sent=(text:string,...sources:string[]):Sentence=>({text,sources});
 const row:EvidenceFinding={id:'synthetic-finding',title:topic==='signals'?'Signal separation':'Harbor arrival spread',peer:{title:`Fictional ${topic} record`,href:'#overview'},use:'Synthetic layout demonstration',population:'24 fictional objects, not participants',comparison:'Invented group A versus invented group B',endpoint:'Synthetic units',timepoint:'Test checkpoint 1',status:'SYNTHETIC · NOT EVIDENCE',finding:'The invented values are 12.5 versus 9.2 synthetic units.',findingSentences:[sent('The invented values are 12.5 versus 9.2 synthetic units.',ids.finding)],magnitude:'The invented difference is 3.3 units.',magnitudeSentences:[sent('The invented difference is 3.3 units.',ids.finding,ids.mechanism,ids.finding)],certainty:{label:'Not applicable: synthetic',rationale:'A layout fixture has no scientific evidence certainty.'},evidenceBase:'Two invented source IDs exercise the presentation. Neither refers to a real study.',limits:[{text:'No actual research or participants exist.',sourceIds:[ids.finding]}],sourceIds:[ids.mechanism,ids.finding],familyIds:[`fixture-${topic}-family`],background:false,pending:['This fixture is never eligible for scientific publication.']};
 const blocks:ReadingBlock[]=[
  {kind:'prose',id:'overview',title:'Overview',paragraphs:[[sent(`This fictional ${topic} example introduces a reading page with one connected explanation.`,ids.overview),sent('All figures and records are invented solely for layout verification.',ids.overview)],[sent('The sections stay readable without opening cards or panels.')]]},
  {kind:'mechanisms',id:'mechanisms',title:syntheticMechanisms(topic).content.heading,original:sent('A fictional sorting rule separates the demonstration inputs.',ids.overview),explanation:sent('An alternative fictional context uses the same sorting rule.',ids.mechanism),source:sent('Synthetic mechanism note, fixture paragraph two.',ids.mechanism),meaning:sent('This invented rule supports no real-world conclusion.')},
  {kind:'findings',id:'findings',title:'Findings',intro:sent('The table retains its semantic columns and invented values.'),row},
  {kind:'prose',id:'safety',title:'Safety',paragraphs:[[sent('This is a nonmedical layout example. Its invented values must not be interpreted as observations.',ids.overview)]]},
  {kind:'faqs',id:'faqs',title:'FAQs',items:[{id:'faq-values',question:'Are the example numbers real observations?',sentences:[sent('No. The values exist only to test this reusable page.',ids.faq)]},{id:'faq-repeat',question:'Does a repeated source receive a new number?',sentences:[sent('No. The same synthetic source keeps its first assigned number.',ids.overview,ids.finding,ids.overview)]}]}
 ];
 const sources:EvidenceSource[]=Object.entries(ids).map(([kind,id])=>({id,title:`Synthetic ${topic} ${kind} note`,url:'#'+sourceReferenceId(id),year:'Synthetic date',kind:'Private fixture',primary:kind==='finding',preview:'All values in this record are invented. This is not research.',decisiveLimit:'No actual experiment or scientific conclusion exists.',access:'Synthetic note below',status:'Synthetic only',population:'Fictional test objects',design:'Layout test, not a study',reviewUrl:'#'+sourceReferenceId(id),reviewLabel:'Read synthetic source note',locators:[`Synthetic ${kind} fixture; no paper locator`]}));
 return {blocks,sources,ids};
}
export function readingCitationGroups(blocks:ReadingBlock[]):string[][]{
 return blocks.flatMap(block=>{
  switch(block.kind){
   case 'prose':return block.paragraphs.flat().map(s=>s.sources);
   case 'mechanisms':return [block.original,block.explanation,block.source,block.meaning].map(s=>s.sources);
   case 'findings':return [block.intro.sources,...(block.row.findingSentences||[]).map(s=>s.sources),...(block.row.magnitudeSentences||[]).map(s=>s.sources),...block.row.limits.map(l=>l.sourceIds)];
   case 'faqs':return block.items.flatMap(item=>item.sentences.map(s=>s.sources));
   default:{const impossible:never=block;throw new Error('Unsupported reading block: '+String(impossible));}
  }
 });
}
export function readingCitationRegistry(model:ReturnType<typeof syntheticReadingModel>){
 const groups=readingCitationGroups(model.blocks),available=model.sources.map(s=>s.id),unknown=unknownCitationIds(groups,available);
 if(unknown.length)throw new Error('Unknown synthetic source identity: '+unknown.join(', '));
 const cited=createCitationOrder(groups,available);
 // Uncited catalogue notes append after article citations; they never seed numbering.
 return [...cited,...available.filter(id=>!cited.includes(id))];
}
export function ReadingCitations({ids,order}:{ids:string[];order:string[]}){
 const unknown=ids.filter(id=>!order.includes(id));if(unknown.length)throw new Error('Unmapped synthetic citation');
 return ids.length?<sup className="citation-sup">{orderCitationGroup(ids,order).map(id=><a key={id} data-source-id={id} href={'#'+sourceReferenceId(id)} aria-label={'Read reference '+citationNumber(id,order)}>[{citationNumber(id,order)}]</a>)}</sup>:null;
}
function FixtureSave({topic}:{topic:SyntheticTopic}){
 const [saved,setSaved]=useState(false);
 return <span className="save-control"><button className="research-hero__center-tag" type="button" aria-pressed={saved} onClick={()=>setSaved(value=>!value)}>{saved?<Check aria-hidden="true"/>:<Bookmark aria-hidden="true"/>}<span>{saved?'Saved in fixture':`Save ${topic==='signals'?'signal':'location'}`}</span></button>{saved?<span role="status">Fixture only; not saved to an account.</span>:null}</span>;
}
export function SyntheticReadingArticle({topic,model=syntheticReadingModel(topic)}: {topic:SyntheticTopic;model?:ReturnType<typeof syntheticReadingModel>}){
 const order=readingCitationRegistry(model),references=useRef<HTMLDetailsElement>(null);
 const cite=(ids:string[])=> <ReadingCitations ids={ids} order={order}/>;
 const sentence=(s:Sentence,index=0)=><span key={index}>{normalizeCitationSentence(s.text)}{cite(s.sources)}{' '}</span>;
 useEffect(()=>{
  const reveal=()=>{let id='';try{id=decodeURIComponent(location.hash.slice(1))}catch{return}const node=document.getElementById(location.hash.slice(1))||document.getElementById(id);if(node&&references.current?.contains(node)){references.current.open=true;node.setAttribute('tabindex','-1');node.focus({preventScroll:true});node.scrollIntoView({block:'start'});}};
  const click=(event:MouseEvent)=>{const anchor=(event.target as Element).closest?.('a[href^="#"]');if(anchor)queueMicrotask(reveal)};
  reveal();window.addEventListener('hashchange',reveal);document.addEventListener('click',click);return()=>{window.removeEventListener('hashchange',reveal);document.removeEventListener('click',click)};
 },[]);
 const groups=[...model.blocks.map(block=>({id:block.id,label:block.title})),{id:'references',label:'References'}];
 return <ArticleLayout hero={{title:`A closer look at ${topic}.`,description:<p>This private synthetic fixture contains no scientific claim, real drug, disease, person or study.</p>,breadcrumbs:[{label:'Fixture home',href:`/?topic=${topic}&view=home`}],kindLabel:'SYNTHETIC FIXTURE',author:syntheticAuthor(topic),art:syntheticHome(topic).hero.image,snapshot:<div className="snapshot"><h2>Fixture snapshot</h2><p>5 invented notes<br/>24 fictional objects<br/>0 real studies</p></div>,actions:<HeroActions ariaLabel="Article actions" saveSlot={<FixtureSave topic={topic}/>} links={[{label:'Safety',href:'#safety',icon:<Shield/>},{label:'FAQs',href:'#faqs',icon:<MessagesSquare/>},{label:'Evidence',href:'#findings',icon:<ChartNoAxesCombined/>},{label:'References',href:'#references',icon:<BookOpen/>}]}/>}} leftRail={<ThemeSectionNav groups={groups}/>} rightRail={<div><h2>Related topic</h2><a href={`/?topic=${topic==='signals'?'locations':'signals'}&view=article`}>Read the other topic</a></div>}>
  {model.blocks.map(block=>{
   switch(block.kind){
    case 'prose':return <section className="article-section" id={block.id} key={block.id}><h2>{block.title}</h2>{block.paragraphs.map((paragraph,i)=><p key={i}>{paragraph.map(sentence)}</p>)}</section>;
    case 'mechanisms':{const config=syntheticMechanisms(topic);return <MechanismSection key={block.id} {...config} originalAction={<p>{sentence(block.original)}</p>} contexts={[{...config.contexts![0],explanation:<p>{sentence(block.explanation)}</p>,evidence:{...config.contexts![0].evidence,source:<>{sentence(block.source)}</>},clinicalMeaning:block.meaning.text}]}/>;}
    case 'findings':return <section className="article-section" id={block.id} key={block.id}><h2>{block.title}</h2><p>{sentence(block.intro)}</p><EvidenceTable rows={[block.row]} sources={model.sources} cite={cite}/></section>;
    case 'faqs':return <InlineFaqs key={block.id} title={block.title} items={block.items.map(item=>({id:item.id,question:item.question,answer:<p>{item.sentences.map(sentence)}</p>}))}/>;
   }
  })}
  <section className="article-section"><details id="references" ref={references}><summary>References</summary><ol className="bibliography">{order.map(id=>{const source=model.sources.find(s=>s.id===id)!;return <li key={id} id={sourceReferenceId(id)} data-source-id={id}><span id={'ref-'+citationNumber(id,order)}/><strong>{source.title}.</strong> All values are invented for this fixture. No DOI or actual paper exists.</li>})}</ol></details></section>
 </ArticleLayout>;
}
