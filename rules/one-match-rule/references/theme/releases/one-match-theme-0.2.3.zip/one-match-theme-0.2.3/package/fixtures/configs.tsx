import React from "react";
import type { ThemeConfig, ThemeHomeContent, ThemeAuthor } from "../src/types";
import {syntheticGuides,fixtureRoute} from "./products";
/** Private test records. Never ingest, index, or present as research. */
export const syntheticConfigA: ThemeConfig = {
  schemaVersion:"1.0.0", identity:{name:"Signal Atlas",homeHref:"/"},
  palette:{main:"#20324f",mainDark:"#17253c",accent:"#f6bc45",pale:"#fff9eb"},
  navigation:[{label:"Signals",href:"/signals"},{label:"Questions",href:"/questions"},{label:"More topics",href:"/explore",mega:{intro:"Explore signals and questions.",columns:[{title:"Browse topics",links:[{label:"Signal Alpha",href:"/signals/alpha",detail:"Open the overview"},{label:"Signal Beta",href:"/signals/beta"}]},{title:"Related questions",links:[{label:"Question Beta",href:"/questions/beta",detail:"Read the connected question"}]}],note:"Browse the full collection for more topics.",allLink:{label:"All signals",href:"/signals"}}},{label:"Guides",href:fixtureRoute("signals","catalogue")},{label:"Methods",href:"/methods"}],
  search:{action:"/search",param:"q",label:"Search Signal Atlas",placeholder:"Find a synthetic test record"},
  accountLink:{label:"Account",href:"/account"},
  footer:{copyright:"Private theme fixture. No scientific content.",columns:[{title:"Explore",links:[{label:"Signals",href:"/signals"}]},{title:"Methods",links:[{label:"Method notes",href:"/methods"}]},{title:"About",links:[{label:"About fixture",href:"/about"}]}],legal:[{label:"Privacy",href:"/privacy"},{label:"Terms",href:"/terms"}]}
};
export const syntheticConfigB: ThemeConfig = {
  ...syntheticConfigA,
  identity:{name:"Harbor Notebook",homeHref:"/"},
  palette:{main:"#264e45",mainDark:"#1d3e37",accent:"#e5ae55",pale:"#fff5de"},
  navigation:[{label:"Locations",href:"/locations"},{label:"Routes",href:"/routes"},{label:"More topics",href:"/explore",mega:{intro:"Explore places and routes.",columns:[{title:"Browse topics",links:[{label:"Harbor One",href:"/locations/one",detail:"Open the overview"},{label:"Harbor Two",href:"/locations/two"}]},{title:"Related questions",links:[{label:"Route note",href:"/process/route",detail:"Read the connected question"}]}],note:"Browse the full collection for more places.",allLink:{label:"All locations",href:"/locations"}}},{label:"Guides",href:fixtureRoute("locations","catalogue")},{label:"Process",href:"/process"}],
  search:{action:"/find",param:"query",label:"Search Harbor Notebook",placeholder:"Find a fictional harbor record"},
  footer:{...syntheticConfigA.footer,columns:[{title:"Locations",links:[{label:"All locations",href:"/locations"}]},{title:"Process",links:[{label:"How to read",href:"/process"}]},{title:"About",links:[{label:"About fixture",href:"/about"}]}]}
};
export function syntheticHome(topic: "signals" | "locations"): ThemeHomeContent {
  const label=topic==="signals"?"Signals":"Locations";
  return {
    hero:{title:`A connected view of ${topic}.`,intro:"A fictional, private fixture for checking the same theme through configuration alone.",image:{src:"/synthetic-art.svg",alt:"Three connected nodes around a document, synthetic layout illustration",width:1448,height:1086},caption:{eyebrow:"PRIVATE FIXTURE",title:"Layout demonstration only"},quickLinks:[{label:`Browse ${topic}`,href:`/${topic}`}],note:{mark:"TEST",title:"Traceable layout.",text:"This fixture makes no scientific claims.",link:{label:"Read fixture method",href:"#method"}}},
    principles:["PRIVATE FIXTURE","CONFIGURATION ONLY","NO SCIENTIFIC CLAIMS"],
    collectionHeading:"Explore a connected collection.",collectionIntro:"The structure stays the same when the topic changes.",
    collections:[{number:"01",eyebrow:label.toUpperCase(),title:`Start with ${topic}`,copy:"Synthetic directory content for layout verification.",href:`/${topic}`,links:[{label:`First ${topic} record`,href:`/${topic}/one`}]},{number:"02",eyebrow:"QUESTIONS",title:"Follow a question",copy:"Synthetic question content for layout verification.",href:"/questions",links:[{label:"A fixture question",href:"/questions/one"}]},{number:"03",eyebrow:"METHODS",title:"Inspect the method",copy:"Synthetic method content for layout verification.",href:"/methods",links:[{label:"A fixture method",href:"/methods/one"}]}],
    method:{title:"From a question to a source.",intro:"Only the presentation is being tested here.",link:{label:"Read fixture notes",href:"/methods"},steps:[{title:"Identify",text:"Select a fictional record."},{title:"Inspect",text:"Open the connected fixture."},{title:"Compare",text:"Check the unchanged layout."}]},
    research:{title:"Browse the fixture records.",link:{label:"All records",href:"/research"},items:[{title:"A synthetic source record",kind:"Fixture only",href:"/research/one"}]},
    guides:{title:`Reading companions for ${topic}.`,text:"This catalogue exercises the same product UI using fictional inputs.",label:"PRIVATE GUIDE FIXTURE",link:{label:"Open fictional guide catalogue",href:fixtureRoute(topic,"catalogue")},items:syntheticGuides(topic).products.map(p=>({title:p.title,description:p.description,href:syntheticGuides(topic).config.routes.products+p.slug,status:p.statusLabel}))},
    join:{title:"Review the fixture.",text:"This call to action is a link, with no signup service or data collection.",content:<a href="/about" className="btn">About this fixture</a>}
  };
}

/** A fictional identity solely for author-interaction tests; no person or ORCID is claimed. */
export function syntheticAuthor(topic: "signals" | "locations"): ThemeAuthor {
  return {id:`fixture-${topic}-editor`,name:`Synthetic ${topic} editor`,role:"Fictional fixture identity",bio:"This is a fictional test identity, not a real author. The abstract illustration, missing ORCID and this biography test the reusable hero disclosure only.",portrait:{src:"/synthetic-art.svg",alt:"Abstract fixture avatar; not a person",width:1448,height:1086}};
}
