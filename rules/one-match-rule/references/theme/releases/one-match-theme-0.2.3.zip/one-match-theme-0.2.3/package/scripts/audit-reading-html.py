"""Parse generated synthetic HTML, not a browser; validate identity/order/structure."""
from html.parser import HTMLParser
import json,sys
class Node:
 def __init__(self,tag='root',attrs=(),parent=None):self.tag=tag;self.attrs=dict(attrs);self.parent=parent;self.children=[]
class Parser(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.root=Node();self.current=self.root
 def handle_starttag(self,tag,attrs):
  node=Node(tag,attrs,self.current);self.current.children.append(node)
  if tag not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:self.current=node
 def handle_startendtag(self,tag,attrs):self.current.children.append(Node(tag,attrs,self.current))
 def handle_endtag(self,tag):
  node=self.current
  while node.parent:
   if node.tag==tag:self.current=node.parent;return
   node=node.parent
 def handle_data(self,data):self.current.children.append(data)
def walk(node):
 yield node
 for child in node.children:
  if isinstance(child,Node):yield from walk(child)
def text(node):return ''.join(child if isinstance(child,str) else text(child) for child in node.children)
def ancestor(node,test):
 while node.parent:
  node=node.parent
  if test(node):return node
 return None
def audit(html,order,label):
 p=Parser();p.feed(html);nodes=list(walk(p.root));checks=[]
 def check(name,passed):checks.append({'name':label+' '+name,'status':'PASS' if passed else 'FAIL'})
 ids={n.attrs['id']:n for n in nodes if 'id'in n.attrs};allids=[n.attrs['id']for n in nodes if'id'in n.attrs]
 check('no duplicate IDs',len(allids)==len(set(allids)))
 check('single main',sum(n.tag=='main' for n in nodes)==1)
 actions=[n for n in nodes if n.tag=='nav' and n.attrs.get('aria-label')=='Article actions']
 check('exactly one hero action row',len(actions)==1)
 if actions:
  action=actions[0];links=[n for n in walk(action)if n.tag=='a'];buttons=[n for n in walk(action)if n.tag=='button']
  check('actions inside hero center',ancestor(action,lambda n:'research-hero__center'in n.attrs.get('class','').split())is not None)
  check('applicable jumps and real targets',[text(n)for n in links]==['Safety','FAQs','Evidence','References'] and all(n.attrs['href'][1:]in ids for n in links))
  check('save supplied by fixture host slot',len(buttons)==1 and buttons[0].attrs.get('aria-pressed')=='false' and text(buttons[0]).startswith('Save '))
  check('all action icons decorative',sum(n.tag=='svg' and n.attrs.get('aria-hidden')=='true' for n in walk(action))==5)
 check('author stays right without duplicate',sum('omr-author'in n.attrs.get('class','').split()for n in nodes)==1 and any(n.attrs.get('data-hero-region')=='author-snapshot' and any('omr-author'in c.attrs.get('class','').split() for c in walk(n)) for n in nodes))
 for id in ['overview','safety']:
  check(id+' prose is visible outside disclosures',id in ids and ancestor(ids[id],lambda n:n.tag=='details')is None and any(n.tag=='p'for n in walk(ids[id])))
 check('evidence table retained',any(n.tag=='table'for n in walk(ids['findings'])))
 faq=ids.get('faq-values');check('FAQ is a native closed disclosure',faq is not None and faq.tag=='details' and 'open'not in faq.attrs and any(n.tag=='summary'for n in faq.children if isinstance(n,Node)))
 check('bibliography closed and canonical',ids['references'].tag=='details' and 'open'not in ids['references'].attrs and sum(n.tag=='ol'and n.attrs.get('class')=='bibliography'for n in nodes)==1)
 sups=[n for n in nodes if n.tag=='sup'and'citation-sup'in n.attrs.get('class','').split()];first=[];bindings=True;groups=True;afterperiod=True
 for sup in sups:
  anchors=[n for n in walk(sup)if n.tag=='a'];numbers=[]
  for a in anchors:
   source=a.attrs.get('data-source-id');number=order.index(source)+1 if source in order else 0;numbers.append(number)
   bindings &= text(a)==f'[{number}]' and a.attrs.get('href')==f'#source-ref-{source}' and ids.get(f'source-ref-{source}') is not None and ids[f'source-ref-{source}'].attrs.get('data-source-id')==source and f'ref-{number}'in ids
   if source not in first:first.append(source)
  groups &= bool(anchors) and numbers==sorted(set(numbers))
  siblings=sup.parent.children;i=siblings.index(sup);prior=siblings[i-1]if i else None;before=prior if isinstance(prior,str)else text(prior)if prior else''
  afterperiod &= before.endswith('.')
 check('all citations linked superscripts with right source target',bool(sups)and bindings)
 check('first new sources sequential in actual SSR reading order',first==order[:len(first)])
 check('citation groups ascending and deduplicated',groups)
 check('superscripts after authored punctuation',afterperiod)
 check('FAQ citations included while closed',any(n.tag=='sup'for n in walk(faq)))
 check('uncited bibliography-only identity does not seed article',len(first)<len(order) and order[0]in first)
 check('decimal numbers preserved','12.5 versus 9.2'in html and'3.3 units.'in html)
 return checks
payload=json.load(sys.stdin);checks=[]
for item in payload:checks+=audit(item['html'],item['order'],item['label'])
print(json.dumps(checks));sys.exit(1 if any(c['status']=='FAIL'for c in checks)else 0)
