/* Node-only fixture verification, no browser/network/service actions. */
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const ts=require('typescript'),React=require('react'),{renderToStaticMarkup}=require('react-dom/server');
const root=path.resolve(__dirname,'..');
require.extensions['.tsx']=require.extensions['.ts']=(module,filename)=>module._compile(ts.transpileModule(fs.readFileSync(filename,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}}).outputText,filename);
require.extensions['.css']=(module)=>{module.exports=new Proxy({},{get:(_,key)=>key==='__esModule'?false:String(key)})};
const {ThemeShell,ThemeHome,ArticleLayout,ThemeSectionNav,DirectoryPage,ArticleHero,AuthorCard,OrcidLink}=require('../src/theme.tsx');
const {syntheticConfigA,syntheticConfigB,syntheticHome,syntheticAuthor}=require('../fixtures/configs.tsx');
const hash=file=>crypto.createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex');
const coreFiles=['src/theme.tsx','src/theme.css','src/theme-source.css','src/theme-home.module.css','src/types.ts'];
const before=Object.fromEntries(coreFiles.map(file=>[file,hash(file)]));
const wrap=(config,child)=>renderToStaticMarkup(React.createElement(ThemeShell,{config},child));
const renders={};
renders.homeA=wrap(syntheticConfigA,React.createElement(ThemeHome,{content:syntheticHome('signals')}));
renders.homeB=wrap(syntheticConfigB,React.createElement(ThemeHome,{content:syntheticHome('locations')}));
const groups=[{id:'overview',label:'Overview',children:[{id:'detail',label:'Detail'}]},{id:'sources',label:'Sources'}];
renders.article=wrap(syntheticConfigA,React.createElement(ArticleLayout,{hero:{title:'Synthetic record',description:'Private fixture, no research conclusion.',breadcrumbs:[{label:'Home',href:'/'}],kindLabel:'Fixture'},leftRail:React.createElement(ThemeSectionNav,{groups}),rightRail:React.createElement('a',{href:'/related'},'Related fixture')},React.createElement('section',{id:'overview'},React.createElement('h2',null,'Overview'),React.createElement('p',null,'Synthetic article body.'))));
renders.directory=wrap(syntheticConfigA,React.createElement(DirectoryPage,{title:'Signals',description:'Synthetic directory.',items:[{id:'a',title:'Alpha',href:'/signals/alpha'},{id:'b',title:'Beta',href:'/signals/beta'}]}));
const checks=[];
function check(name,pass){checks.push({name,status:pass?'PASS':'FAIL'});if(!pass)process.exitCode=1}
for(const [name,html] of Object.entries(renders)){
 check(name+' single header/footer/main',(html.match(/<header\b/g)||[]).length===1&&(html.match(/<footer\b/g)||[]).length===1&&(html.match(/<main\b/g)||[]).length===1);
 check(name+' source identity absent',!/(Microbiome Medicine|Microbiome Signatures|microbiomemedicine\.com|PepsAnon|supabase|\/api\/subscribe|wp-content)/i.test(html));
 check(name+' configured main target',html.includes('href="#main-content"')&&html.includes('id="main-content"'));
}
check('configuration-only identity swap',renders.homeA.includes('Signal Atlas')&&!renders.homeB.includes('Signal Atlas')&&renders.homeB.includes('Harbor Notebook'));
check('configuration-only search route',renders.homeA.includes('action="/search"')&&renders.homeB.includes('action="/find"'));
check('configuration-only palette',renders.homeA.includes('--omr-main:#20324f')&&renders.homeB.includes('--omr-main:#264e45'));
check('same structural home markup',renders.homeA.match(/<main[\s\S]*<\/main>/)[0].match(/class="[^"]+"/g).join('|')===renders.homeB.match(/<main[\s\S]*<\/main>/)[0].match(/class="[^"]+"/g).join('|'));
check('repeat render idempotent',wrap(syntheticConfigA,React.createElement(ThemeHome,{content:syntheticHome('signals')}))===renders.homeA);
check('shared core unchanged',JSON.stringify(before)===JSON.stringify(Object.fromEntries(coreFiles.map(file=>[file,hash(file)]))));
check('directory all identities',renders.directory.includes('/signals/alpha')&&renders.directory.includes('/signals/beta'));
// Latest owner right-hero correction: author ownership and hero regions must survive every adapter path.
const author=syntheticAuthor('signals');
const hero=props=>wrap(syntheticConfigA,React.createElement(ArticleHero,{title:'Synthetic hero',breadcrumbs:[],snapshot:React.createElement('p',null,'SNAPSHOT-MARKER'),...props}));
const defaultHero=hero({author});
const left=html=>html.slice(html.indexOf('data-hero-region="image"'),html.indexOf('class="research-hero__center"'));
const region=html=>html.slice(html.indexOf('data-hero-region="author-snapshot"'),html.indexOf('</aside>'));
const right=html=>html.slice(html.indexOf('class="research-hero__right"'),html.indexOf('</aside>'));
check('configured author is in right hero region',region(defaultHero).includes('class="omr-author"')&&defaultHero.includes('research-hero--with-author'));
check('one right-hero author and snapshot; no left author',(defaultHero.match(/class="omr-author"/g)||[]).length===1&&!left(defaultHero).includes('omr-author')&&right(defaultHero).includes('omr-author')&&right(defaultHero).includes('SNAPSHOT-MARKER'));
const preferred=hero({author,creditSlot:React.createElement('span',null,'LEGACY-MARKER'),authorSlot:React.createElement('span',null,'AUTHOR-SLOT-MARKER')});
check('authorSlot has explicit precedence',region(preferred).includes('AUTHOR-SLOT-MARKER')&&!preferred.includes('LEGACY-MARKER')&&!preferred.includes('class="omr-author"'));
check('legacy creditSlot resolves to right hero region',region(hero({creditSlot:React.createElement('span',null,'LEGACY-MARKER')})).includes('LEGACY-MARKER'));
const suppressed=hero({author,authorSlot:null});
check('explicit null authorSlot suppresses fallback',!suppressed.includes('omr-author')&&!suppressed.includes('research-hero--with-author'));
const missing=wrap(syntheticConfigA,React.createElement(AuthorCard,{author:{...author,portrait:undefined}}));
check('missing author assets are explicit',missing.includes('Portrait not supplied')&&missing.includes('ORCID iD not supplied')&&!missing.includes('https://orcid.org/'));
const identity=wrap(syntheticConfigA,React.createElement(AuthorCard,{author:{...author,orcid:'SYNTHETIC-NOT-AN-ORCID'}}));
check('invalid synthetic identity never produces a misleading ORCID link',identity.includes('ORCID iD not supplied')&&!identity.includes('href="https://orcid.org/'));
const otherHero=hero({author:syntheticAuthor('locations')});
check('second configured author uses the same hero structure',region(otherHero).includes('Synthetic locations editor')&&otherHero.match(/class="[^"]+"/g).join('|')===defaultHero.match(/class="[^"]+"/g).join('|'));
// Shape-only synthetic identifiers below are never assigned to a fixture author or clicked.
const identityMarkup=id=>renderToStaticMarkup(React.createElement(OrcidLink,{orcid:id,name:'Format-only fixture'}));
const id='0000-0000-0000-0000';
const canonical=identityMarkup(id);
check('ORCID has linked green20px iD SVG and visible identifier',canonical.includes('href="https://orcid.org/'+id+'"')&&canonical.includes('fill="#A6CE39"')&&canonical.includes('<svg width="20" height="20"')&&canonical.includes('ORCID iD · '+id));
check('canonical URL normalized without duplicate domain',identityMarkup(' https://orcid.org/'+id+'/ ')===canonical);
check('case-insensitive canonical host normalized',identityMarkup('HTTPS://ORCID.ORG/'+id)===canonical);
check('ORCID accessible name is assigned-person specific',canonical.includes('aria-label="Format-only fixture ORCID iD '+id+'"')&&canonical.includes('aria-hidden="true"'));
for(const [name,value] of [['missing',undefined],['empty',''],['foreign domain','https://example.invalid/'+id],['script URL','javascript:alert(1)'],['malformed','123'],['URL query','https://orcid.org/'+id+'?x=1']])check(name+' does not generate ORCID link',!identityMarkup(value).includes('<a '));
const css=fs.readFileSync(path.join(root,'src/theme.css'),'utf8');
check('old intermediate left-meta grid absent',!css.includes('grid-template-areas:"media main" "meta main"'));
check('right hero generic biography anchored toward page interior',css.includes('.research-hero__author .omr-author__bio { left:auto; right:0; }'));
check('author slot does not duplicate in body context rail',!renders.article.includes('omr-author')&&region(defaultHero).includes('omr-author'));
const out=path.join(root,'validation');fs.mkdirSync(out,{recursive:true});
for(const [name,html]of Object.entries(renders))fs.writeFileSync(path.join(out,name+'.html'),html);
fs.writeFileSync(path.join(out,'core-check.json'),JSON.stringify({status:process.exitCode?'FAIL':'PASS',scope:'Node SSR + source invariants; no visual/browser/service validation claimed',coreHashes:before,checks,renderHashes:Object.fromEntries(Object.entries(renders).map(([k,v])=>[k,crypto.createHash('sha256').update(v).digest('hex')]))},null,2)+'\n');
console.log(JSON.stringify({status:process.exitCode?'FAIL':'PASS',checks:checks.length}));
