/* Reproducible presentational dependency extraction. Source files are inputs, never changed. */
const fs = require('fs'), path = require('path');
const source = process.argv[2];
if (!source) throw Error('Usage: node extract-source-css.cjs /path/to/references/theme [postcss-module]');
const postcss = require(process.argv[3] || 'postcss');
const target = path.resolve(__dirname, '..');
const selected = [], rejected = [];
const allowed = /^(?:header(?:__|$)|footer(?:__|$)|menu(?:-|$)|sub-menu|custom-logo|img-|wrapper$|main$|site-content$|btn(?:--|$)|field(?:__|--|$)|subscribe(?:__|--|$)|rgbc-search|research-hero|research-content|post-content|post-sidebar|breadcrumb|badge$|entry-content$|article$|rgbc-hero|rgbc-archive|rgbc-content|snapshot|screen-reader-text$|sr-only$)/;
const input = path.join(source,'microbiome-medicine/src/styles/theme-wp.css');
function keepSelector(s) {
  if (/admin-bar|\.single|#page|wp-block|drooltip|\[style|:root|:where\(/.test(s)) return false;
  const classes=[...s.matchAll(/\.([a-zA-Z_-][\w-]*)/g)].map(m=>m[1]);
  if (classes.length) return classes.some(c => allowed.test(c)) && !classes.some(c=>/^auth|wall|modal|research-diagram/.test(c));
  return !/#|@|\[x-data\]|\[data-modal/.test(s);
}
function transform(node) {
  if (node.type==='comment') return null;
  if (node.type==='atrule') {
    if (!['media','supports'].includes(node.name)) return null;
    const out=node.clone({nodes:[]}); (node.nodes||[]).forEach(n=>{const t=transform(n);if(t)out.append(t)});return out.nodes.length?out:null;
  }
  if(node.type!=='rule') return null;
  const selectors=node.selectors.filter(keepSelector);
  if(!selectors.length){rejected.push(node.selector);return null}
  selected.push({selector:node.selector,sourceLine:node.source.start.line});
  const copy=node.clone();
  copy.selectors=selectors.map(s=>/^html$|^body$/.test(s)?'.omr-theme':'.omr-theme '+s.replace(/\bhtml\b|\bbody\b/g,'.omr-theme')).map(s=>s.replace(/^\.omr-theme \.omr-theme/,'.omr-theme'));
  copy.walkDecls(d=>{
    if (d.prop==='--color-primary' || (d.prop==='font-family' && d.value.includes('""'))) {d.remove();return}
    d.value=d.value.replace(/#cc3333(?:90|80|20|10)?\b/gi, 'var(--color-primary)').replace(/#a02727\b/gi,'var(--color-primary-dark)').replace(/#f7e6e6\b/gi,'var(--omr-pale)').replace(/#c33\b/gi,'var(--color-primary)');
  });return copy;
}
const out=postcss.root();postcss.parse(fs.readFileSync(input,'utf8')).nodes.forEach(n=>{const t=transform(n);if(t)out.append(t)});
// Search styles reside inside the active captured header, outside theme-wp.css.
const html=fs.readFileSync(path.join(source,'microbiome-medicine/src/theme/themeHtml.ts'),'utf8');
const header=JSON.parse(html.match(/export const HEADER_HTML = (.*);/)[1]);
const inline=header.match(/<style[^>]*>([\s\S]*?)<\/style>/)[1];
postcss.parse(inline).nodes.forEach(n=>{const t=transform(n);if(t)out.append(t)});
fs.writeFileSync(path.join(target,'src/theme-source.css'), '/* GENERATED from pinned active theme-wp.css and header search. Do not hand edit. */\n'+out.toString());
// Keep the entire active HomePage stylesheet. Only brand tokens and required hero overlay differ.
let home=fs.readFileSync(path.join(source,'microbiome-medicine/src/components/home/HomePage.module.css'),'utf8');
home=home.replace('--home-ink: #1a1a2e','--home-ink: var(--omr-ink, #1a1a2e)').replace('--home-muted: #6c757d','--home-muted: var(--omr-muted, #6c757d)');
fs.writeFileSync(path.join(target,'src/theme-home.module.css'),home+'\n/* OMR-03: adopted homepage composition. Preserve the active layout, use configured main field and helpful art. */\n.home .hero { background:var(--omr-main); color:var(--omr-pale); }\n.home .hero h1 { color:var(--omr-pale); }\n.home .hero__intro,.home .quick-searches { color:var(--omr-pale); }\n.home .quick-searches a {color:var(--omr-accent);border-color:var(--omr-accent)}\n.home .image-frame {background:var(--omr-pale)}\n.home .hero__media {display:block}\n.home .search button {background:var(--omr-accent);color:var(--omr-main)}\n.home .search button:hover {background:var(--omr-pale);color:var(--omr-main)}\n');
fs.writeFileSync(path.join(target,'css-source-map.json'),JSON.stringify({source:"microbiome-medicine/src/styles/theme-wp.css",selectedRuleCount:selected.length,omittedRuleCount:rejected.length,selectedRules:selected},null,2)+'\n');
console.log(JSON.stringify({selectedRules:selected.length,omittedRules:rejected.length,cssBytes:out.toString().length}));
