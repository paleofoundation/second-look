/** Public host DTO contract only. No storage implementation, credentials or real records. */
export type PurchaseView = {
  productId:string|null; title:string;
  status:'paid'|'pending'|'failed'|'refunded'|'disputed'|'cancelled'|'unknown';
  currency:string|null; totalMinor:number|null; createdAt:string; updatedAt:string;
  editionVersion:string|null; downloadAvailable:boolean;
};
export type AvailableGuideView = {
  productId:string; title:string; slug:string; editionId:string; version:string;
  access:'owned'|'membership'; downloadUrl:string; summaryDownloadUrl:string|null;
};
export type GuideLibraryView = {
  commerce:'not_launched'; purchases:PurchaseView[];
  membership:{state:string;expiresAt:string|null}|null;
  availableGuides:AvailableGuideView[]; message:string;
};
/** Caller credentials and ownership checks are handled by a server adapter, never these inputs. */
export type GuideLibraryClient = {read:()=>Promise<GuideLibraryView>};
