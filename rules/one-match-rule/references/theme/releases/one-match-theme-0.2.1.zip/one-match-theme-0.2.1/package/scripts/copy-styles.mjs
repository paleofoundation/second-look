import { readdir, copyFile } from 'node:fs/promises';
for(const file of await readdir(new URL('../src/',import.meta.url))) if(file.endsWith('.css')) await copyFile(new URL('../src/'+file,import.meta.url),new URL('../dist/'+file,import.meta.url));
