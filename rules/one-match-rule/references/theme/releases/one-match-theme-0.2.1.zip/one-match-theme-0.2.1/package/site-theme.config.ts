/** Synthetic configuration example. Supply destination identity, routes and verified authors. */
export { syntheticConfigA as siteThemeConfig } from "./fixtures/configs";
