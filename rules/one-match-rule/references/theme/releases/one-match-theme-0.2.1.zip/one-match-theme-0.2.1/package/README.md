# Source-derived One Match theme 0.2.1

Private React presentation package derived from the active Microbiome Medicine shell/home at commit `28ed85b6d510dfddf1720775b456771c7dc62763`, with scoped PepsAnon and current-rule corrections. Version 0.2.1 corrects author placement to the right side of the hero and adds a universal green-logo OrcidLink. It retains the configured menu, planned guide catalogue and confidence modules from immutable v0.2.0. It is a reusable source package; source-kit omissions and real service/publication acceptance remain explicit.

## Install

Use Node 22.13+, React/React DOM 18.2–19 and a bundler that handles TypeScript and CSS modules. The workspace's exact tested dependencies are declared in its package files. Install this directory as a local dependency or vendor it with `assets/` intact. It has no WordPress, Next, Supabase or network-font dependency.

```tsx
import { ThemeShell, ThemeHome } from '@one-match/source-theme';
import { GuideCatalogue } from '@one-match/source-theme/guides';
import { describeEvidenceConfidence } from '@one-match/source-theme/confidence';
import '@one-match/source-theme/theme.css';
import '@one-match/source-theme/reading-modules.css';
import '@one-match/source-theme/guide-library.css';

// Exactly one shared shell. Home and ArticleLayout already include a main.
<ThemeShell config={siteConfig}>
  <main id={siteConfig.mainId || 'main-content'}>
    <GuideCatalogue products={publicProducts} offer={plannedOffer}
      config={guidePresentation} notice={topicNotice} />
  </main>
</ThemeShell>
```

CSS order matters. `theme.css` imports scoped source rules and local fonts; `reading-modules.css` and `guide-library.css` follow. Preserve `assets/fonts` relative to the package. Mount only one header/footer/shell. `ThemeHome`, `ArticleLayout` and `DirectoryPage` emit their own main landmark; guide components do not. Add the host main only around components that need one.

## Configure, do not fork

`src/types.ts`, `fixtures/configs.tsx` and `fixtures/products.ts` show the complete inputs. `site-theme.config.ts` exports an explicitly synthetic starting config, not a destination assignment.

- `ThemeConfig`: identity, main/accent/pale palette, search action/parameter, navigation and footer. `ThemeNavItem.mega` holds grouped links, introductory text, provenance note and all-topics link. Order is host data: distinguish dated measured interest from editorial coverage; the component does not score popularity. Old `children` remains compatible; use the megamenu for a large topic catalogue.
- `ThemeHomeContent`: configured hero/art, collection/method/research content and optional `guides` collection. All topic text and links are inputs.
- `ArticleHero` / `ArticleLayout`: right hero author/snapshot region, content and rails. Prefer `authorSlot`; legacy `creditSlot` is an alias. Explicit null suppresses the generic fallback. Otherwise `author` supplies verified identity, portrait and visible linked ORCID. The shared author handles click/focus/Escape; native pointer-travel and physical-touch acceptance remain separate.
- `DirectoryPage`: supplied canonical A–Z records. `ThemeSearch`: host GET route and optional async suggestions. `ThemeAdapters.Link` and `.Image` default to native anchors/images.
- `EvidenceTable`, `InlineFaqs`, `OutcomeFinder`: subpath exports preserving source identities, per-sentence citations, right research panel and canonical filter inputs. Supply only public summaries, never protected review bodies.
- `GuideCatalogue`, `GuideProductDetail`, `GuideMembership`, `MedicalScopeNotice`: public product configuration via `GuidePresentation`, `GuideProductView` and `GuideOffer`. Brand/headline/shelf/free resource and all guide route URLs are inputs. `routes.products` is a prefix to a supplied slug (use a trailing slash or deliberate query prefix). Components use ordinary anchors, so all routes must work without client-only navigation. `MedicalScopeNotice` accepts a cancer flag and disclaimer URL; notices still need qualified review where relevant.
- `describePendingConfidence` / `describeEvidenceConfidence`: a pure adapter preserves row-specific recorded limits/action and explicit missingness. Study design does not assign a rating. An assessed label requires supplied assessed status, method, scope and rationale, with integrity holds taking precedence. This is a rendering gate, not a validated appraisal method or human-approval check.

The guide UI is **planned-offer presentation**. It always communicates unavailable purchase and proposed prices; `offer.enabled` and `releaseState` are data fields, not a checkout switch. A host requiring released-sale behavior must add a versioned, server-authorized integration and test the complete flow. Do not claim this package sells or delivers guides. Paid guide products are separate from the free authenticated research-review policy.

## Checks and builds

From the exported workspace root, run `npm run check` then `npm run build`. Within this package, `npm run typecheck`, `npm run check:core`, `npm run check:products` and `npm run build` work after dependencies are installed. The build emits JS/declarations/styles in `dist`; the documented bundler entry remains source exports. Core checks use SSR and source invariants; product checks use synthetic guide/menu/confidence inputs, including missing-method, missing-scope and quarantine failure cases. The sibling proof app covers two configurations without changing shared code and includes deterministic repeated generation.

No fixture is evidence, a price recommendation, measured demand, a real person or a purchasable product. Keep fixture routes outside production indexes. SSR/typecheck/build do not prove browser interaction, medical/legal review, account isolation, payment or file authorization. Consult `theme-acceptance.json` for the exact tested state.

## Provenance and limits

Manifests record source/dependency closure and current-rule overlays. Inter/Lora regular font binaries and OFL notices are included. Source reuse is private and owner-authorized; no public third-party source license is inferred. The original kit lacks database `wp_render.html`, `_migration/endo-live.html` and `_migration/x-cond.html`, so full captured-article parity remains HOLD. Original source classes and native layout remain reused. No site or canonical rule was modified by this export worker.

The CSS extraction utility is a source-maintenance tool requiring the immutable source kit; ordinary users should not rerun it as installation. Current-rule CSS lives in `theme.css` and is pinned with the export.

## Migration from 0.1.1

Supply `navigation[].mega` for grouped discovery, optional `ThemeHomeContent.guides`, `GuidePresentation` and public product metadata. Add `guide-library.css` after existing styles. Keep scientific/appraisal and interest-provenance decisions in canonical host data. Replace old status-only confidence cells with the shared row-specific adapter while preserving evidence holds. No account database migration, payment configuration or new evidence is part of this UI package.

## Migration from 0.2.0

`authorSlot` and the generic `author` now render once inside `data-hero-region="author-snapshot"`, above edition/snapshot content. `creditSlot` follows the same location. Left artwork is separate. Remove host overrides that force an author into the left media region or body sidebar. Import `OrcidLink` from the root export for every displayed ORCID; pass the assigned person’s verified identifier or canonical URL. The icon and identifier share a canonical HTTPS link. Do not copy actual author identity into fixtures. Missing/malformed input remains explicit and unlinked. Recheck desktop, intermediate width and stacked mobile layout plus biography focus/close and clipping. Previous v0.2.0 browser proof is historical, not a current rerun.
