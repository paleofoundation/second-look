# Host adapters and access boundary

The presentation package has no account database, credentials, user records, corpus, scientific approval engine or billing configuration. It consumes public rendering props and a small set of explicit adapters. These interfaces reflect the implemented pilot source without carrying its records or identity assignments.

## Presentation and source data

`ThemeConfig` supplies identity, palette, navigation, search route/parameter and footer links. Optional `Link`, `Image` and `searchSuggestions` adapters connect to the host framework/index. `ThemeHomeContent` and `ArticleHeroProps` contain destination text/assets, verified author assignments and safe rendered slots. Install `theme.css` once before `reading-modules.css`. Mount one root shell; every page retains exactly one main landmark and the configured skip target.

`EvidenceTable` takes `EvidenceFinding[]`, `EvidenceSource[]` and a citation renderer. Use stable canonical source/family IDs. New `findingSources` and sentence-level `findingSentences`/`magnitudeSentences` keep each scientific sentence with its own source set; editorial status text can have no citation. The panel holds public summaries and permitted facts, never a protected full review. Do not use a union of every row citation to imply every paper supports every sentence. The URL assigned to `reviewUrl` must resolve to the canonical review route and preserve its return destination through authentication.

`InlineFaqs` consumes structured React answers so citation elements survive. It supports stable FAQ fragments. `OutcomeFinder` consumes canonical outcome/synthesis records and `renderRows(ids)` returns the original records without recomputing certainty. It persists filter state in `outcome_*` query parameters. Optional `canonicalOutcomeId`, `registryState`, `instrument`, `hierarchy`, `measuredDirection`, `scaleDirection`, `meaningfulChange` and `definitionCitation` expose the separate registry fields. Missingness must remain explicit in the host data; do not infer a clinical direction or threshold from a label.

## Account and intake adapter

The host implementation uses a server-trusted identity shaped as `{userId:string}`. Its account resolver returns `{user, profile, error}`. A profile contains the intake contract version, selected role values, `complete` or `declined` state and completion/update times. Identity is assigned by the authenticated server session, never supplied by a form body or query. The client profile view omits the user ID.

The implemented continuation flow is: sign in through the supported host → account continuation → required current intake when missing or unreadable → original same-site destination. A deliberate `prefer_not_to_say` choice is valid and exclusive. A profile-read/write failure is a retryable error, not implicit completion. Selected roles are self-reported and grant no staff or editorial permissions.

Concrete route pattern supported by the reference adapter:

- `/account/continue?returnTo=<same-site-path>` chooses sign-in, intake or destination.
- `/signin-with-chatgpt?return_to=<encoded-continuation>` is the current host sign-in entry; replace it when a host uses another supported authentication service.
- `/account/intake?returnTo=<same-site-path>` and `/account/profile` implement first-login and editable profile flows.
- The profile API uses authenticated GET/PUT/DELETE and optional export, with server-assigned ownership. Mutation requests enforce same-origin and an expected JSON content type.

The host validates return paths: relative same-origin only, no protocol-relative URL, control/backslash or repeated-encoding bypass, API target or authentication loop. Private responses use private/no-store caching and vary on the actual authenticated session/identity mechanism. Storage and private saved-library authorization belong to server adapters. No theme component proves isolation or persistence.

## Full-review access

The current policy is `free_authenticated`; payment does not grant or deny this phase's access. The repository contract separates `getPublic(id)` (metadata/preview only) from `readProtected(id)` (full review, called only after authorization). Before a protected read, the server checks current persisted intake, exact content hash/version, released status, actual human editorial approval and applicable qualified safety approval. It then verifies the retrieved content hash and Q01–Q15 completion/locator contract. Pending or withdrawn reviews remain public previews with an honest reason, even for signed-in users.

Do not serialize a full review into anonymous HTML, client hydration, public API/search/export/cache or the evidence panel. Pass only allowlisted public previews to client components. The host must test anonymous/expired/new/intake-incomplete/complete/declined/second-user cases, unsafe return paths, write failures and cross-account operations. This package carries interfaces and presentation only; deployment-specific security results remain in the host's acceptance records.

## Hero author adapter (0.2.1 / rule v1.20)

Pass one verified host author card as `hero.authorSlot`, or pass `hero.author` for the generic card. `creditSlot` remains a deprecated alias, now rendered in the right hero author/snapshot region. A supplied slot overrides the generic author; explicit null suppresses the fallback. The author lives above the snapshot in the hero right region. Do not put a second author card in `leftContext`, the snapshot content itself, or the contextual body rail. Use `leftContext` only for additional non-author media context.

The shared responsive hero keeps the author inside the hero right region; on narrow screens that region stacks below the title. The former intermediate-width left-meta grid is removed. Host cosmetics may customize a transparent portrait over the configured accent without overriding these placement rules. The author slot must provide matching real identity/portrait/bio, the visible linked ORCID iD, portrait hover/focus and activation, pointer travel containment, keyboard/touch close, and Escape focus return without reopening. No host biography or profile is bundled here.

## Version 0.2.0 discovery, confidence and product adapters

`ThemeNavItem.mega` is presentation of ordered, provenance-labelled groups. A host must retain the measurement window, source/community, denominators, duplicates and coverage limits in canonical data. Do not turn editorial requirements or synthetic demo ordering into a measured popularity ranking. Required targets must remain discoverable even when not ranked popular. The shared trigger supports click, ArrowDown entry and Escape/focus return; the mobile drawer owns its own focus loop and scroll lock. Browser acceptance is required after host styling/routing changes.

`describeEvidenceConfidence` returns supplied appraisal metadata only when its status, method, scope and rationale are present. This function does not verify the scientific method, reconstruct missing studies, infer certainty from randomized design or confer reviewer approval. The host must validate exact source/outcome scope and approval before supplying assessed metadata. A pending row needs a useful recorded limitation and next action; placeholders are explicit missing-data errors to resolve, not a replacement for permitted synthesis.

`GuidePresentation` supplies brand copy, catalogue/product-prefix/library/membership/disclaimer routes and an optional free resource. Product fields are public metadata and preview links only. Format prices as integer minor units with explicit currency. This v0.2.0 UI describes planned pricing and unavailable sales even if a caller supplies `enabled:true`; it does not implement a released-sale variant. Subscription inclusion and perpetual edition purchase rights remain different concepts. Never put unpublished guide bytes, protected review prose, internal file keys, customer/order IDs or reviewer records into these props.

The reference host's private guide library contract is included as `adapters/contracts.ts` (also exported as `/host-contracts`). It is an interface, not a backend. Its current read endpoint is `GET /api/purchases` with a server-authenticated session; the response includes public purchases, optional membership state and available guides. A host may use different supported routes while preserving the same behavior. An edition ID is only a public selector. A download URL never proves entitlement.

The reference download shape is `GET /api/guides/<editionId>/download`, optionally `?format=summary`. The server authenticates the reader and checks exact product/edition rights, independent purchase ownership versus membership dates, current released state, content and marketing hashes, exact-edition editorial approval, qualified clinical approval and legal/marketing approval where relevant. Medical product status must override a wrongly nonmedical edition flag. After authorization, the server obtains private bytes and verifies their hash before sending a private/no-store response. `GET /api/purchases` must not expose private file keys, user/order IDs or reviewer records.

Expected boundaries: 401 requests sign-in; 400 rejects malformed selectors/account query attempts; 403 covers unavailable entitlement or release; 404 can identify an absent summary; 503 makes database/storage/hash failures retryable without exposing bytes. The server assigns ownership from the trusted session, not a request body/userId. Tests must cover second-account isolation, expired membership with independent purchased rights, refunds/disputes, exact edition hashes, source/readiness holds, cache behavior, full/summary bytes and raw path bypasses. A fake paid row or visible lock is not acceptable.

The theme does not ship the host's D1 migration, SQL tables, billing/webhook logic, authentication provider or data. It does not create accounts, grant purchases or deploy. The demo's My guides link ends at a clear service-boundary page; real My guides must be integrated and tested separately. The separate manuscript/PDF renderer workstream produces edition artifacts and manifests; this UI consumes its public metadata, never assumes a draft PDF is commercially released.

`OrcidLink({orcid,name})` is exported from the theme entry and used by the generic author and host card. It renders a small green iD mark and visible identifier in the same canonical HTTPS link, with a person-specific accessible name. Missing or malformed identifiers produce explicit missingness without a false link. Its format check does not verify identity: supply only the assigned person’s previously verified canonical record. Keep the ORCID link separate from the biography trigger.
