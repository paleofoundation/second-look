import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.dirname(fileURLToPath(import.meta.url));
export default defineConfig({
  root, plugins:[react()], resolve:{dedupe:['react','react-dom']},
  server:{host:'127.0.0.1',port:5188,strictPort:true,fs:{allow:[root,path.resolve(root,'../package')]},watch:{usePolling:true,interval:350}},
  build:{outDir:'dist',emptyOutDir:true}
});
