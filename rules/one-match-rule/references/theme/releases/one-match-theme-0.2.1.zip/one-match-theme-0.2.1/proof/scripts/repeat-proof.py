from pathlib import Path
import subprocess,sys,hashlib,json
root=Path(__file__).resolve().parents[1]
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
package=root.parent/'package'
files=sorted(p for p in (package/'src').rglob('*') if p.is_file())
before={p.relative_to(package).as_posix():h(p) for p in files}
subprocess.run([sys.executable,str(root/'scripts/generate.py')],check=True,capture_output=True)
first={f:h(root/f) for f in ['generated.json','public/synthetic-art.svg']}
subprocess.run([sys.executable,str(root/'scripts/generate.py')],check=True,capture_output=True)
second={f:h(root/f) for f in first}
after={p.relative_to(package).as_posix():h(p) for p in files}
result={'status':'PASS' if first==second and before==after else 'FAIL','generatedFiles':second,'unchangedSharedFiles':before==after,'byteIdenticalSecondRun':first==second,'sharedFileCount':len(files),'noTimestamps':True,'scope':'Generation and source hashes only. Browser acceptance is separate.'}
(root/'repeat-run-proof.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result));assert result['status']=='PASS'
