from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
package=root.parent/'package'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=sorted([p for p in (package/'src').rglob('*') if p.is_file()]+list((package/'fixtures').glob('*'))+list((package/'assets/fonts').glob('*')))
data={'schemaVersion':'1.0.0','purpose':'Private synthetic theme proof; no real research','topics':['signals','locations'],'views':['home','article','catalogue','product','membership','adapter'],'exactSharedFiles':{p.relative_to(package).as_posix():h(p) for p in files},'fixtureFiles':{name:h(root/name) for name in ['main.tsx','proof.css','index.html','vite.config.ts']},'routes':['/?topic='+topic+'&view='+view for topic in ['signals','locations'] for view in ['home','article','catalogue','product','membership','adapter']],'sharedPackageFilesMutated':False,'deployments':0}
(root/'public').mkdir(exist_ok=True)
(root/'public/synthetic-art.svg').write_bytes((package/'fixtures/synthetic-art.svg').read_bytes())
(root/'generated.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
print(h(root/'generated.json'))
