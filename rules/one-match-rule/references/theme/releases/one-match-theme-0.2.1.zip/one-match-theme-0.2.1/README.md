# One Match theme 0.2.1 — portable private workspace

This React source package and local proof app reuse the same shared theme. It adds configured grouped navigation, a planned guide catalogue/product/membership presentation, a home guide collection, and row-specific confidence explanations. It contains no real research corpus, author identity, account database, private guide files or checkout service.

## Run the two-topic proof

Requirements: Node 22.13+ (tested with the local installed runtime), npm, and Python 3 for deterministic proof generation. In this extracted directory:

```sh
npm install --ignore-scripts
npm run check
npm run build
npm run dev
```

Open `http://127.0.0.1:5188/?topic=signals&view=home`, then use the fixture bar to switch topic and page. The second configuration is `?topic=locations&view=home`. Views include `home`, `article`, `catalogue`, `product`, `membership` and `adapter`. All identities, numerical findings, prices and product records are explicitly synthetic. The fixture runs locally, has no indexable research content, and does not deploy anything.

The topic query selects data/configuration only. Both topics import unchanged `package/src`. The demo has no actual search index or account services: its route adapter sends ordinary example links to a synthetic article, and account/library links lead to a truthful service-boundary page. The real host must implement and test those services.

## Integrate into a real host

Install the `package/` directory as a local dependency, for example `npm install ../one-match-theme-0.2.1/package`, or vendor that directory while preserving its assets. Import source exports through a TypeScript/CSS-module-capable bundler. See [package/README.md](package/README.md), [package/HOST-ADAPTERS.md](package/HOST-ADAPTERS.md) and the typed fixtures. Do not copy synthetic data into production, and do not copy another site's scientific claims, names, accounts or pricing.

`theme-manifest.json` records exact source hashes and provenance. `theme-acceptance.json` separates current technical and synthetic checks from browser, visual parity and real service gates. The original captured database article HTML is not in the source kit; its visual parity is not certified. The package has no automatic billing or access-policy change. Released research reviews remain free after supported login and persisted reader intake.

`npm run build` builds both package declarations/styles and the static proof bundle. The source files are the host package entry; the proof `dist/` is a local demonstration, not a production evidence site. Package checks write only their local `validation/` outputs. Font licenses are in `package/assets/fonts/`.
